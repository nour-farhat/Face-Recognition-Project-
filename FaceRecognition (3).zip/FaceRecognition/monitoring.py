import time
import cv2
from tkinter import *
from tkinter import filedialog, messagebox
from tkinter.ttk import Treeview
import pandas as pd


def run_attendance_monitoring(app):
    names = list(app.system.embeddings.keys())
    app.attendance_df = pd.DataFrame({'Name': names, 'Present': [0] * len(names)})
    start_time = time.time()
    cap = cv2.VideoCapture(0)
    last_time = 0

    while True:
        current_time = time.time()
        elapsed_minutes = (current_time - start_time) / 60.0

        if elapsed_minutes >= 15:
            break

        ret, frame = cap.read()
        if not ret:
            break

        if current_time - last_time >= 1:
            verified, identity, score = app.system.verify_face(frame)
            if verified and identity in app.attendance_df['Name'].values:
                status = app.attendance_df.loc[app.attendance_df['Name'] == identity, 'Present'].values[0]
                if status == 0:
                    app.attendance_df.loc[app.attendance_df['Name'] == identity, 'Present'] = 2 if elapsed_minutes >= 10 else 1
            last_time = current_time

        cv2.putText(frame, "Press 'q' to quit | Press 'r' to report", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.imshow("Attendance Monitoring", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('r'):
            app.root.after(0, app.report_incorrect)

    cap.release()
    cv2.destroyAllWindows()
    show_attendance_summary(app)

def run_continuous_monitoring(app):
    cap = cv2.VideoCapture(0)
    last_time, label, color = 0, "", (0, 0, 255)

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        current_time = time.time()
        if current_time - last_time >= 1:
            verified, identity, score = app.system.verify_face(frame)
            if verified:
                label = f"Access Granted: {identity} ({score:.2f})"
                color = (0, 255, 0)
            else:
                label = f"Access Denied ({score:.2f})"
                color = (0, 0, 255)
            last_time = current_time
        cv2.putText(frame, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
        cv2.putText(frame, "Press 'q' to quit | Press 'r' to report", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.imshow("Continuous Monitoring", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('r'):
            app.root.after(0, app.report_incorrect)

    cap.release()
    cv2.destroyAllWindows()

def show_attendance_summary(app):
    win = Toplevel(app.root)
    win.title("Attendance Summary")
    tree = Treeview(win, columns=("Name", "Present"), show='headings')
    tree.heading("Name", text="Name")
    tree.heading("Present", text="Present")
    tree.pack(fill=BOTH, expand=True)

    status_map = {0: "Absent", 1: "Present", 2: "Late"}
    for _, row in app.attendance_df.iterrows():
        readable = status_map.get(row['Present'], "Unknown")
        tree.insert("", END, values=(row['Name'], readable))

    def save_csv():
        filename = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if filename:
            app.attendance_df.to_csv(filename, index=False)
            messagebox.showinfo("Saved", f"Attendance saved to {filename}")

    Button(win, text="Save CSV", command=save_csv).pack(pady=10)
