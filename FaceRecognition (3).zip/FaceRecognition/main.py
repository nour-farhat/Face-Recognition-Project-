from tkinter import Tk
from gui import FaceRecognitionApp

if __name__ == "__main__":
    root = Tk()
    app = FaceRecognitionApp(root)
    root.mainloop()
