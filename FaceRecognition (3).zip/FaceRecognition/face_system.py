import os
import cv2
import pickle
import numpy as np
from deepface import DeepFace
from sklearn.metrics.pairwise import cosine_similarity

class FaceRecognitionSystem:
    def __init__(self, db_path=None, threshold=0.7):
        self.threshold = threshold
        self.embeddings = {}
        self.model_name = 'Facenet512'
        self.detector_backend = 'retinaface'
        if db_path:
            self.load_database(db_path)

    def register_face(self, name, image):
        try:
            augmented_images = self.augment_image_variants(image)
            for aug_img in augmented_images:
                embedding_objs = DeepFace.represent(
                    img_path=aug_img,
                    model_name=self.model_name,
                    detector_backend=self.detector_backend,
                    enforce_detection=True
                )
                embedding = embedding_objs[0]['embedding']
                self.embeddings.setdefault(name, []).append(embedding)
            return True
        except Exception as e:
            print(f"Error registering face for {name}: {e}")
            return False

    def augment_image_variants(self, image):
        variants = [image]
        try:
            hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
            for val in [40, -40]:
                img_hsv = hsv.copy()
                img_hsv[:, :, 2] = cv2.add(img_hsv[:, :, 2], val)
                bright = cv2.cvtColor(img_hsv, cv2.COLOR_HSV2BGR)
                variants.append(bright)
            contrast = cv2.convertScaleAbs(image, alpha=1.3, beta=0)
            blur = cv2.GaussianBlur(image, (3, 3), 0)
            variants.extend([contrast, blur])
        except Exception as e:
            print(f"Error in image augmentation: {e}")
        return variants

    def verify_face(self, image):
        try:
            processed = self.preprocess_image_for_verification(image)
            embedding_objs = DeepFace.represent(
                img_path=processed,
                model_name=self.model_name,
                detector_backend=self.detector_backend,
                enforce_detection=True
            )
            embedding = embedding_objs[0]['embedding']
            best_match, highest_similarity = None, -1
            for name, stored_embeddings in self.embeddings.items():
                for stored_embedding in stored_embeddings:
                    similarity = cosine_similarity([embedding], [stored_embedding])[0][0]
                    if similarity > highest_similarity:
                        highest_similarity = similarity
                        best_match = name
            return highest_similarity >= self.threshold, best_match, highest_similarity
        except Exception as e:
            print(f"Error verifying face: {e}")
            return False, None, -1

    def preprocess_image_for_verification(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        norm = clahe.apply(gray)
        return cv2.cvtColor(norm, cv2.COLOR_GRAY2BGR)

    def save_database(self, filepath='face_database.pkl'):
        try:
            with open(filepath, 'wb') as f:
                pickle.dump(self.embeddings, f)
        except Exception as e:
            print(f"Error saving database: {e}")

    def load_database(self, filepath):
        if os.path.exists(filepath):
            try:
                with open(filepath, 'rb') as f:
                    self.embeddings = pickle.load(f)
            except Exception as e:
                print(f"Error loading database: {e}")
                self.embeddings = {}

    def clear_database(self):
        self.embeddings = {}
        self.save_database()

    def update_user_embeddings(self, name, image):
        self.embeddings[name] = []
        self.register_face(name, image)
        self.save_database()
