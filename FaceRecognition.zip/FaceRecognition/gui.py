import os
import time
import cv2
import pandas as pd
from tkinter import *
from tkinter import filedialog, messagebox, simpledialog
from face_system import FaceRecognitionSystem
from monitoring import start_attendance_monitoring, start_continuous_monitoring

class FaceRecognitionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Face Recognition System")
        self.system = FaceRecognitionSystem(db_path='face_database.pkl')
        self.attendance_df = pd.DataFrame(columns=['Name', 'Present'])
        self.monitoring_active = False

        Button(root, text="Attendance Monitoring", command=self.attendance_menu, width=30).pack(pady=10)
        Button(root, text="Continuous Monitoring", command=self.continuous_menu, width=30).pack(pady=10)
        Button(root, text="Exit", command=root.quit, width=30).pack(pady=10)

    def attendance_menu(self):
        self.monitoring_menu("Attendance")

    def continuous_menu(self):
        self.monitoring_menu("Continuous")

    def monitoring_menu(self, mode):
        win = Toplevel(self.root)
        win.title(f"{mode} Monitoring Menu")

        if mode == "Attendance":
            Button(win, text="Start Camera Monitoring", command=lambda: start_attendance_monitoring(self)).pack(pady=5)
        else:
            Button(win, text="Start Camera Monitoring", command=lambda: start_continuous_monitoring(self)).pack(pady=5)

        Button(win, text="Register New Person", command=self.register_user).pack(pady=5)
        Button(win, text="List Registered Users", command=self.list_users).pack(pady=5)
        Button(win, text="Load LFW Dataset", command=self.load_lfw).pack(pady=5)
        Button(win, text="Clear All Users", command=self.clear_users).pack(pady=5)
        Button(win, text="Close Menu", command=win.destroy).pack(pady=5)

    def register_user(self):
        name = simpledialog.askstring("Input", "Enter name:")
        if not name:
            return
        poses = ["Face forward", "Turn left", "Turn right"]
        for pose in poses:
            messagebox.showinfo("Pose", f"Please: {pose}")
            cap = cv2.VideoCapture(0)
            time.sleep(1)
            ret, frame = cap.read()
            cap.release()
            if ret:
                success = self.system.register_face(name, frame)
                if not success:
                    messagebox.showerror("Error", f"Failed to register {pose} for {name}")
                    return
            else:
                messagebox.showerror("Error", "Failed to capture image from camera.")
                return
        self.system.save_database()
        messagebox.showinfo("Success", f"Registered {name}")

    def list_users(self):
        users = list(self.system.embeddings.keys())
        if users:
            messagebox.showinfo("Registered Users", "\n".join(users))
        else:
            messagebox.showinfo("No Users", "No identities registered.")

    def load_lfw(self):
        path = filedialog.askdirectory()
        if not path:
            return
        count = 0
        for person_name in os.listdir(path):
            person_folder = os.path.join(path, person_name)
            if not os.path.isdir(person_folder):
                continue
            img_files = [f for f in os.listdir(person_folder) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            if not img_files:
                continue
            img_path = os.path.join(person_folder, img_files[0])
            img = cv2.imread(img_path)
            if img is not None:
                success = self.system.register_face(person_name, img)
                if success:
                    count += 1
        self.system.save_database()
        messagebox.showinfo("Loaded", f"Loaded {count} users from LFW dataset.")

    def clear_users(self):
        if messagebox.askyesno("Confirm", "Clear all registered identities?"):
            self.system.clear_database()
            messagebox.showinfo("Cleared", "All identities cleared.")