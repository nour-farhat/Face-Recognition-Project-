import cv2
import time
import threading
from tkinter import Toplevel, BOTH, Button, filedialog, messagebox
from tkinter.ttk import Treeview
import pandas as pd

def start_attendance_monitoring(app):
    names = list(app.system.embeddings.keys())
    app.attendance_df = pd.DataFrame({'Name': names, 'Present': [0] * len(names)})
    app.monitoring_active = True
    start_time = time.time()

    def monitor():
        cap = cv2.VideoCapture(0)
        last_time = 0

        while app.monitoring_active:
            current_time = time.time()
            elapsed_minutes = (current_time - start_time) / 60.0

            if elapsed_minutes >= 15:
                print("⏰ 15 minutes passed. Ending attendance session.")
                break

            ret, frame = cap.read()
            if not ret:
                break

            if current_time - last_time >= 1:
                verified, identity, score = app.system.verify_face(frame)
                if verified and identity in app.attendance_df['Name'].values:
                    current_status = app.attendance_df.loc[app.attendance_df['Name'] == identity, 'Present'].values[0]
                    if current_status == 0:
                        if elapsed_minutes >= 10:
                            app.attendance_df.loc[app.attendance_df['Name'] == identity, 'Present'] = 2
                            print(f"[LATE] {identity} marked late (⏱ {elapsed_minutes:.2f} mins).")
                        else:
                            app.attendance_df.loc[app.attendance_df['Name'] == identity, 'Present'] = 1
                            print(f"[ON TIME] {identity} marked present (⏱ {elapsed_minutes:.2f} mins).")
                last_time = current_time

            cv2.putText(frame, "Press 'q' to quit", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            cv2.imshow("Attendance Monitoring", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()
        app.monitoring_active = False
        show_attendance_summary(app)

    threading.Thread(target=monitor).start()

def show_attendance_summary(app):
    summary_win = Toplevel(app.root)
    summary_win.title("Attendance Summary")

    tree = Treeview(summary_win, columns=("Name", "Present"), show='headings')
    tree.heading("Name", text="Name")
    tree.heading("Present", text="Present")
    tree.pack(fill=BOTH, expand=True)

    status_map = {0: "Absent", 1: "Present", 2: "Late"}
    for _, row in app.attendance_df.iterrows():
        readable_status = status_map.get(row['Present'], "Unknown")
        tree.insert("", 'end', values=(row['Name'], readable_status))

    def save_csv():
        filename = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if filename:
            app.attendance_df.to_csv(filename, index=False)
            messagebox.showinfo("Saved", f"Attendance saved to {filename}")

    Button(summary_win, text="Save CSV", command=save_csv).pack(pady=10)

def start_continuous_monitoring(app):
    app.monitoring_active = True

    def monitor():
        cap = cv2.VideoCapture(0)
        last_time = 0
        label = ""
        color = (0, 0, 255)
        while app.monitoring_active:
            ret, frame = cap.read()
            if not ret:
                break
            current_time = time.time()
            if current_time - last_time >= 1:
                verified, identity, score = app.system.verify_face(frame)
                if verified:
                    label = f"Access Granted: {identity} ({score:.2f})"
                    color = (0, 255, 0)
                else:
                    label = f"Access Denied ({score:.2f})"
                    color = (0, 0, 255)
                last_time = current_time
            cv2.putText(frame, label, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
            cv2.putText(frame, "Press 'q' to quit", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            cv2.imshow("Continuous Monitoring", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        cap.release()
        cv2.destroyAllWindows()

    threading.Thread(target=monitor).start()